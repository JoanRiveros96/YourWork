module.exports ={
    secret: 'mysecrettoken'
}