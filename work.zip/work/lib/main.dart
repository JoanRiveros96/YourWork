import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:work/view/loginPage.dart';
void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'App Nodejs Mogodb',
      theme: ThemeData(
        
        primarySwatch: Colors.blue,
      ),
      home: MainPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  



  SharedPreferences sharedPrefences;
  @override
  void initState(){
    super.initState();
    checkLoginStatus();
  }

  

  checkLoginStatus() async {
    sharedPrefences = await SharedPreferences.getInstance();
    if(sharedPrefences.getString("token")==null){
      Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (BuildContext context)=>LoginPage()), (Route<dynamic> route )=> false);
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Nodejs-Mongodb", style: TextStyle(color: Colors.white )),
        actions: <Widget>[
          FlatButton(
            onPressed: (){
              sharedPrefences.clear();
              //sharedPrefences.commit();              
              Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (BuildContext context)=>LoginPage()), (Route<dynamic> route )=> false);
            },
            child: Text("Logout", style: TextStyle(color: Colors.white),),
          )
        ],
      ),
      body: Center(child: Text("MainPage")),
      drawer: Drawer(
        child: new ListView(
          children: <Widget>[
            new UserAccountsDrawerHeader(
              accountName: new Text("Nodejs"),
              accountEmail: new Text("codigoalphaco@gmail.com"),
              ),
              new ListTile(title: new Text("List Products"),
              trailing: new Icon(Icons.list),
              onTap: (){},
              ),
              new ListTile(title: new Text("Add Products"),
              trailing: new Icon(Icons.add),
              onTap: (){},
              ),
              new ListTile(title: new Text("Register user"),
              trailing: new Icon(Icons.add),
              onTap: (){},
              ),
          ]
        )
      ),
      
    );
  }
}